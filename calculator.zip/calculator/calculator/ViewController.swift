//
//  ViewController.swift
//  calculator
//
//  Created by Dylan Dove on 5/22/15.
//  Copyright (c) 2015 Dylan Dove. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //the label that displays our numbers
    @IBOutlet weak var screen: UILabel!
    
    var firstNumber = 0
    var secondNumber = 0
    var operatorPressed = false
    var newNumber = true
    var operation = ""
    
    @IBAction func buttonClear(sender: AnyObject) {
        //code that runs when the clear button is pressed
        screen.text = "0"
        firstNumber = 0
        secondNumber = 0
        operatorPressed = false
        newNumber = true
    }
    
    @IBAction func buttonNegate(sender: AnyObject) {
        //code that runs when the negate button is pressed
    }
    
    @IBAction func buttonPercent(sender: AnyObject) {
        //code that runs when the percent button is pressed
    }
    
    
    @IBAction func buttonDivide(sender: AnyObject) {
        //code that runs when the divide button is pressed
    }
    
    
    @IBAction func buttonMultiply(sender: AnyObject) {
        //code that runs when the multiply button is pressed
    }
    
    
    @IBAction func buttonSubtract(sender: AnyObject) {
        //code that runs when the subtract button is pressed
        if (!operatorPressed && screen.text != "0") {
            //if an operator hasn't been pressed yet, set firstNumber = to screen
            firstNumber = screen.text!.toInt()!
            operatorPressed = true
            operation = "subtract"
            
        }

    }
    
    
    @IBAction func buttonAdd(sender: AnyObject) {
        //code that runs when the add button is pressed
        if (!operatorPressed && screen.text != "0") {
            //if an operator hasn't been pressed yet, set firstNumber = to screen
            firstNumber = screen.text!.toInt()!
            operatorPressed = true
            operation = "add"
            
        }
    }
    
    
    @IBAction func buttonEqual(sender: AnyObject) {
        //code that runs when the equal button is pressed
        if (operation == "add") {
            screen.text = (String)(firstNumber + screen.text!.toInt()!)
            operatorPressed = false
        }
        else if(operation == "subtract") {
            screen.text = (String)(firstNumber - screen.text!.toInt()!)
            operatorPressed = false
        }
        
    }
    
    
    @IBAction func buttonDecimal(sender: AnyObject) {
        //code that runs when the decimal button is pressed
    }
    
    
    @IBAction func buttonZero(sender: AnyObject) {
        //code that runs when the zero button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "0"
            } else {
                screen.text! += "0"
            }
        } else {
            if (newNumber) {
                screen.text = "0"
                newNumber = false
            } else {
                screen.text! += "0"
            }
        }
    }
   
    
    @IBAction func buttonOne(sender: AnyObject) {
        //code that runs when the one button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "1"
            } else {
                screen.text! += "1"
            }
        } else {
            if (newNumber) {
                screen.text = "1"
                newNumber = false
            } else {
                screen.text! += "1"
            }
        }
    }
    
    
    @IBAction func buttonTwo(sender: AnyObject) {
        //code that runs when the two button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "2"
            } else {
                screen.text! += "2"
            }
        } else {
            if (newNumber) {
                screen.text = "2"
                newNumber = false
            } else {
                screen.text! += "2"
            }
        }
    }
    
    
    @IBAction func buttonThree(sender: AnyObject) {
        //code that runs when the three button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "3"
            } else {
                screen.text! += "3"
            }
        } else {
            if (newNumber) {
                screen.text = "3"
                newNumber = false
            } else {
                screen.text! += "3"
            }
        }
    }
    
    @IBAction func buttonFour(sender: AnyObject) {
        //code that runs when the four button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "4"
            } else {
                screen.text! += "4"
            }
        } else {
            if (newNumber) {
                screen.text = "4"
                newNumber = false
            } else {
                screen.text! += "4"
            }
        }
    }
    
    @IBAction func buttonFive(sender: AnyObject) {
        //code that runs when the five button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "5"
            } else {
                screen.text! += "5"
            }
        } else {
            if (newNumber) {
                screen.text = "5"
                newNumber = false
            } else {
                screen.text! += "5"
            }
        }
    }
    
    @IBAction func buttonSix(sender: AnyObject) {
        //code that runs when the six button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "6"
            } else {
                screen.text! += "6"
            }
        } else {
            if (newNumber) {
                screen.text = "6"
                newNumber = false
            } else {
                screen.text! += "6"
            }
        }
    }
    
    @IBAction func buttonSeven(sender: AnyObject) {
        //code that runs when the seven button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "7"
            } else {
                screen.text! += "7"
            }
        } else {
            if (newNumber) {
                screen.text = "7"
                newNumber = false
            } else {
                screen.text! += "7"
            }
        }
    }
    
    @IBAction func buttonEight(sender: AnyObject) {
        //code that runs when the eight button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "8"
            } else {
                screen.text! += "8"
            }
        } else {
            if (newNumber) {
                screen.text = "8"
                newNumber = false
            } else {
                screen.text! += "8"
            }
        }
    }
    
    @IBAction func buttonNine(sender: AnyObject) {
        //code that runs when the nine button is pressed
        if (!operatorPressed) {
            //if operator hasn't been pressed, add number to screen
            if (screen.text == "0") {
                screen.text = "9"
            } else {
                screen.text! += "9"
            }
        } else {
            if (newNumber) {
                screen.text = "9"
                newNumber = false
            } else {
                screen.text! += "9"
            }
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

