//
//  ViewController.swift
//  ImageMove
//
//  Created by Dylan Dove on 6/2/15.
//  Copyright (c) 2015 Dylan Dove. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ball: UIImageView!
    var ballX = 100
    var ballY = 100
    var ballSpeed = 4
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        ball.center.x = CGFloat(ballX)
        ball.center.y = CGFloat(ballY)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func moveBall(sender: AnyObject) {
        var index = 0
        while (index < 20) {
          ball.center.x += CGFloat(ballSpeed)
            index += 1
        }
        
        
        
    }

  

}

