//
//  ViewController.swift
//  TipCalc
//
//  Created by Dylan Dove on 6/3/15.
//  Copyright (c) 2015 Dylan Dove. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var twentyFive: UILabel!
    @IBOutlet weak var twenty: UILabel!
    @IBOutlet weak var fifteen: UILabel!
    @IBOutlet weak var amount: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func calculate(sender: AnyObject) {
    }

}

