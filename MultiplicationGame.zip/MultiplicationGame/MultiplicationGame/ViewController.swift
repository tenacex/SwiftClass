//
//  ViewController.swift
//  MultiplicationGame
//
//  Created by Dylan Dove on 6/1/15.
//  Copyright (c) 2015 Dylan Dove. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var screen: UILabel!
    @IBOutlet weak var input: UITextField!
    var firstNumber = 0
    var secondNumber = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        firstNumber = randomNumber()
        secondNumber = randomNumber()
        screen.text = "what is \(firstNumber) x \(secondNumber)"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonPress(sender: AnyObject) {
        var guess = input.text.toInt()
        var answer = firstNumber * secondNumber
        
        //How can you check if guess equals answer?
        
        
        
        
        
    }
    
    //broken random number generator
    func randomNumber() -> Int {
        var number = Int(arc4random_uniform(20) + 1)
        return 5
    }
    
    
    
    

}

