//
//  GameScene.swift
//  Breakout
//
//  Created by Dylan Dove on 6/8/15.
//  Copyright (c) 2015 Dylan Dove. All rights reserved.
//

import SpriteKit

/* collision detection, ignore */
let BallCategory   : UInt32 = 0x1 << 0
let BottomCategory : UInt32 = 0x1 << 1
let BlockCategory  : UInt32 = 0x1 << 2
let PaddleCategory : UInt32 = 0x1 << 3


/*  global variables for the game  */
var direction = "none"
var paddle = SKShapeNode(rectOfSize: CGSize(width: 80, height: 20))
var ball = SKShapeNode(circleOfRadius: 10)


class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        
        /*  Used to detect when player loses the game */
        let bottomRect = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, 1)
        let bottom = SKNode()
        bottom.physicsBody = SKPhysicsBody(edgeLoopFromRect: bottomRect)
        bottom.physicsBody!.categoryBitMask = BottomCategory
        
        
        /*  make the border of the game make the ball bounce  */
        let borderBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        borderBody.friction = 0
        self.physicsBody = borderBody
        
        /*  adjust characteristics of the ball */
        ball.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        ball.position = CGPointMake(100, 400)
        ball.fillColor = SKColor.orangeColor()
        ball.physicsBody?.restitution = 1
        ball.physicsBody?.linearDamping = 0
        ball.physicsBody?.friction = 0
        ball.name = "ball"
        ball.physicsBody?.angularDamping = 0
        ball.physicsBody!.categoryBitMask = BallCategory
        ball.physicsBody!.contactTestBitMask = BottomCategory | BlockCategory
        
        
        /*  adjust characteristics of the paddle */
        paddle.fillColor = SKColor.whiteColor()
        paddle.position = CGPointMake(187.5, 20)
        paddle.physicsBody = SKPhysicsBody(rectangleOfSize: CGSizeMake(80, 20))
        paddle.physicsBody?.dynamic = false
        paddle.name = "paddle"
        paddle.physicsBody!.categoryBitMask = PaddleCategory
        
        
        /*  adjust physics of the game scene */
        self.physicsWorld.gravity = CGVectorMake(0, 0)
        physicsWorld.contactDelegate = self
        
        
        
        /*  add sprites to game scene */
        self.addChild(paddle)
        self.addChild(ball)
        self.addChild(bottom)
        
        
        /* initiate all of the block in the game  */
        let numberOfBlocks = 5
        var offset = 8           // The space between the blocks
        
        for i in 0..<numberOfBlocks {
            var block = SKShapeNode(rectOfSize: CGSize(width: 60, height: 18))
            block.fillColor = SKColor.redColor()
            block.position = CGPointMake(CGFloat(45 + (60 * i) + offset) ,CGFloat(600))
            block.physicsBody = SKPhysicsBody(rectangleOfSize: block.frame.size)
            block.physicsBody?.dynamic = false
            block.physicsBody?.categoryBitMask = BlockCategory
            self.addChild(block)
            offset += 8
        }
        
        
        /*  apply impulse to ball to start game */
        ball.physicsBody?.applyImpulse(CGVectorMake(0, -4))
        
    
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        // 1. Create local variables for two physics bodies
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        
        // 2. Assign the two physics bodies so that the one with the lower category is always stored in firstBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        // 3. react to the contact between ball and bottom
        if firstBody.categoryBitMask == BallCategory && secondBody.categoryBitMask == BottomCategory {
            //TODO: Replace the log statement with display of Game Over Scene
            println("Hit bottom.")
        } else if firstBody.categoryBitMask == BallCategory && secondBody.categoryBitMask == BlockCategory {
            println("Delete the block!")
            secondBody.node?.removeFromParent()
        }
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        /* Called when a touch begins */
        
        for touch in (touches as! Set<UITouch>) {
            let location = touch.locationInNode(self)
            if (location.x > 225) {
                direction = "right"
            }
            else if (location.x < 150) {
                direction = "left"
            }
            
        }
    }
    
    override func touchesEnded(touches: Set<NSObject>, withEvent event: UIEvent) {
        direction = "none"
    }
    
    override func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
        for touch in (touches as! Set<UITouch>) {
            let location = touch.locationInNode(self)
            if (location.x > 225) {
                direction = "right"
            }
            else if (location.x < 150) {
                direction = "left"
            } else {
                direction = "none"
            }
        }
    }
    
    
   
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        if (direction == "right") {
            if (paddle.position.x < 340) {
                paddle.position.x += 5
            }
            
        } else if (direction == "left") {
            if (paddle.position.x > 35) {
                paddle.position.x -= 5
            }
            
        }
    }
}
